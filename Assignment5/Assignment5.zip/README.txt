****************************
** 
** README.txt             
**
** Assignment 5           
**
** Skylar Shyu | u1039726 
**
****************************

Please extract ALL files from the ZIP! As requested, figures and plots may 
be found in the output folder, while the script and any dependent functions 
may be found in the functions folder. 

***********************
 Compiling and Running
***********************

*
Open up main.m in the functions directory and hit 'run'; this will run all of the matlab files associated with all 3 questions of the assignment.


Question 1 wanted us to write the Tsexact function; it may be found under functions --> Tsexact.m
Question 2 plot output may be found under output --> FWD_EULER
Question 3 wanted us to implement the ODE23 function; it may be found under functions --> ODE23.m
Question 4 and 5 plots are in the same figure under output --> ODE23
Question 6's change for r is captured in figures in output --> R06 suffix 