q1;
q2;
q3;
hold on;
q4cond;
hold on;
q4iterref
