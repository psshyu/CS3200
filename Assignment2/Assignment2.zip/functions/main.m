Q3NewtonCotes;
hold on;            %ensures that figures aren't being overwritten by the next script call
Q3GaussianQuads;